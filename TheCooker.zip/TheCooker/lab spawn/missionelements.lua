if rawget(_G, "localization_TC") then
	if not Network:is_server() then
		return
	end
	
	local flare_table = {
		--flare spawn 1 - 102261
		--102290, --interact flare
		--102203, --waypoint flare
		--102205, --flare on ground
		102245, --effect
		102249, --sound
		102115, --supply bag
		102152, --supply bag waypoint
		
		--flare spawn 2 - 102260
		--102291, --interact flare
		--102202, --waypoint flare
		--102207, --flare on ground
		102250, --effect
		102251, --sound
		102116, --supply bag
		102153, --supply bag waypoint
		
		--flare spawn 3 - 102259
		--102292, --interact flare
		--102201, --waypoint flare
		--102208, --flare on ground
		102252, --effect
		102253, --sound
		102117, --supply bag
		102154 --supply bag waypoint
	}
	
	local global_toggle_event_ran = false
	local function run_event(event)
		local player = managers.player:player_unit()
		if not (player or alive(player)) then
			return
		end
		for _, data in pairs(managers.mission._scripts) do
			for id, element in pairs(data:elements()) do
				if (id == event) then
					global_toggle_event_ran = true
					element:on_executed(player)
					break
				end
			end
		end
	end
	
	if string.lower(RequiredScript) == "core/lib/managers/mission/coremissionscriptelement" and MissionScriptElement and managers.job then
		local id_level = managers.job:current_level_id()
	
		if (id_level == "pal") then
			local orig_MissionScriptElement_on_executed_TC_pal = MissionScriptElement.on_executed
			function MissionScriptElement:on_executed(...)
				if (localization_TC.config.other.twitch_stay_close_pal) and (self._id == 134763 or self._id == 134813 or self._id == 134863 or self._id == 134713) then
				else
					orig_MissionScriptElement_on_executed_TC_pal(self, ...)
				end
			end
		elseif (id_level == "rat") then
			local orig_MissionScriptElement_on_executed_TC_rat = MissionScriptElement.on_executed
			function MissionScriptElement:on_executed(...)
				if localization_TC.config.other.twitch_stay_close and (self._id == 102316) then
					self._values.enabled = false
				end
				orig_MissionScriptElement_on_executed_TC_rat(self, ...)

				if self._id == 100329 then
					self._values.rotation = Rotation(-90, 0, -0)
					--default values for 2nd floor lab position x, y, z
					--(x and y being right or left. z being the hight of the lab)
					self._values.position = Vector3(2036, 800, 1725)
				end
				
				if localization_TC.config.other.twitch_stay_close_spawn and not global_toggle_event_ran then
					run_event(101127) --van showup at start, very buggy
				end
				
				if localization_TC.config.other.supply_bag_spawn_balcony then --flare balcony
					for k, v in pairs(flare_table) do
						if self._id == v then
							self._values.position = Vector3(2416.56, 454.75, 1732.52)
							break
						end
					end
				end
				
				if localization_TC.config.other.supply_bag_spawn_first_floor then --flare first floor
					for k, v in pairs(flare_table) do
						if self._id == v then
							self._values.position = Vector3(1867.92, 1348.91, 1340.93)
							break
						end
					end
				end
				
				if localization_TC.config.other.supply_bag_spawn_second_floor then --flare second floor
					for k, v in pairs(flare_table) do
						if self._id == v then
							self._values.position = Vector3(1623.996, 762.787, 1740.94)
							break
						end
					end
				end
				
				if localization_TC.config.other.supply_bag_spawn_basement_floor then --flare basement
					for k, v in pairs(flare_table) do
						if self._id == v then
							self._values.position = Vector3(1797.26, 482.39, 940.93)
							break
						end
					end
				end
				
				if localization_TC.config.other.supply_bag_spawn_roof then --flare roof
					for k, v in pairs(flare_table) do
						if self._id == v then
							self._values.position = Vector3(1918.531, 950.589, 2204.413)
							break
						end
					end
				end

				if localization_TC.config.other.meth_lab_roof and (self._id == 100330) then
					self._values.rotation = Rotation(-90, 0, -0)
					--roof lab position x, y, z (x and y being right or left. z being the hight of the lab)
					self._values.position = Vector3(1964.79, 700.00, 2100.00)
				end
				
				if localization_TC.config.other.meth_lab_basement and (self._id == 100486) then
					self._values.enabled = true
				end
				
				if localization_TC.config.other.meth_lab_basement and (self._id == 100332) then
					self._values.rotation = Rotation(-90, 0, -0)
					--basement lab position x, y, z (x and y being right or left. z being the hight of the lab)
					self._values.position = Vector3(1900, 875, 924.84) --Vector3(2080, 975, 924.84)
				end
				
				if localization_TC.config.other.meth_lab_disable_middle and (self._id == 100485) then
					self._values.enabled = false
				end
				
				if localization_TC.config.other.meth_lab_disable_top and (self._id == 100483) then
					self._values.enabled = false
				end
			end
		elseif (id_level == "mex_cooking") then
			local orig_MissionScriptElement_on_executed_TC_mex = MissionScriptElement.on_executed
			function MissionScriptElement:on_executed(...)
				orig_MissionScriptElement_on_executed_TC_mex(self, ...)

				if localization_TC.config.other.meth_escape_point_mex and not global_toggle_event_ran then
					run_event(102302)
				end
			end
		end
	end
end