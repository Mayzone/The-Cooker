local function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

local function in_mainmenu()
	if (game_state_machine:current_state_name() == "menu_main") then
		return true
	end
	return false
end

local lang = localization_TC:get_language()
local id_level = managers.job:current_level_id()

local mission_table = {
	["pal"] = {
		{ text = string.format("%s", lang.menu_autocook), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker.lua")) end },
		{ text = string.format("%s", lang.menu_semi_auto), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker semi auto.lua")) end },
		{ text = string.format("%s", lang.menu_auto_secure), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure.lua")) end },
		{ text = string.format("%s", lang.menu_auto_bag), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker bag meth.lua")) end },
		{ text = string.format("%s", lang.menu_box), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker fc.lua")) end },
		{ text = string.format("%s", lang.menu_public), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker announce.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_more_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker more bags.lua")) end },
		{ text = string.format("%s", lang.menu_less_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker less bags.lua")) end }
	},
	["crojob2"] = {
		{ text = string.format("%s", lang.menu_autocook), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker.lua")) end },
		{ text = string.format("%s", lang.menu_semi_auto), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker semi auto.lua")) end },
		{ text = string.format("%s", lang.menu_auto_secure), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure.lua")) end },
		{ text = string.format("%s", lang.menu_auto_bag), callback_func = function() 
			dofile(string.format(localization_TC.config.other.file_path.."autocooker bag meth.lua"))
			if not global_toggle_bag_meth then
				managers.chat:_receive_message(1, lang.cooker, string.format("%s", lang.menu_ex_warning), tweak_data.system_chat_color)
			end
		end },
		{ text = string.format("%s", lang.menu_public), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker announce.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_more_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker more bags.lua")) end },
		{ text = string.format("%s", lang.menu_less_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker less bags.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_secure_all), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure all.lua")) end }
	},
	["alex_1"] = {
		{ text = string.format("%s", lang.menu_autocook), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker.lua")) end },
		{ text = string.format("%s", lang.menu_semi_auto), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker semi auto.lua")) end },
		{ text = string.format("%s", lang.menu_auto_secure), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure.lua")) end },
		{ text = string.format("%s", lang.menu_auto_bag), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker bag meth.lua")) end },
		{ text = string.format("%s", lang.menu_circuit), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker fc.lua")) end },
		{ text = string.format("%s", lang.menu_public), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker announce.lua")) end },
		{ text = string.format("%s", lang.menu_less_spam), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker spam.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_more_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker more bags.lua")) end },
		{ text = string.format("%s", lang.menu_less_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker less bags.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_secure_all), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure all.lua")) end }
	},
	["rat"] = {
		{ text = string.format("%s", lang.menu_autocook), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker.lua")) end },
		{ text = string.format("%s", lang.menu_semi_auto), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker semi auto.lua")) end },
		{ text = string.format("%s", lang.menu_auto_secure), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure.lua")) end },
		{ text = string.format("%s", lang.menu_auto_bag), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker bag meth.lua")) end },
		{ text = string.format("%s", lang.menu_circuit), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker fc.lua")) end },
		{ text = string.format("%s", lang.menu_public), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker announce.lua")) end },
		{ text = string.format("%s", lang.menu_less_spam), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker spam.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_more_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker more bags.lua")) end },
		{ text = string.format("%s", lang.menu_less_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker less bags.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_secure_all), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure all.lua")) end }
	},
	["mia_1"] = {
		{ text = string.format("%s", lang.menu_autocook), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker.lua")) end },
		{ text = string.format("%s", lang.menu_semi_auto), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker semi auto.lua")) end },
		{ text = string.format("%s", lang.menu_auto_secure), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure.lua")) end },
		{ text = string.format("%s", lang.menu_auto_bag), callback_func = function() 
			dofile(string.format(localization_TC.config.other.file_path.."autocooker bag meth.lua"))
			if not global_toggle_bag_meth then
				managers.chat:_receive_message(1, lang.cooker, string.format("%s", lang.menu_ex_warning), tweak_data.system_chat_color)
			end
		end },
		{ text = string.format("%s", lang.menu_public), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker announce.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_more_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker more bags.lua")) end },
		{ text = string.format("%s", lang.menu_less_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker less bags.lua")) end },
	},
	["mex_cooking"] = {
		{ text = string.format("%s", lang.menu_autocook), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker.lua")) end },
		{ text = string.format("%s", lang.menu_semi_auto), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker semi auto.lua")) end },
		{ text = string.format("%s", lang.menu_auto_secure), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure.lua")) end },
		{ text = string.format("%s", lang.menu_auto_bag), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker bag meth.lua")) end },
		{ text = string.format("%s", lang.menu_public), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker announce.lua")) end },
		{ text = string.format("%s", lang.menu_less_spam), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker spam.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_more_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker more bags.lua")) end },
		{ text = string.format("%s", lang.menu_less_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker less bags.lua")) end }
	},
	["cane"] = {
		{ text = string.format("%s", lang.menu_autocook), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker.lua")) end },
		{ text = string.format("%s", lang.menu_auto_bag), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker bag meth.lua")) end },
		{ text = string.format("%s", lang.menu_auto_secure), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure.lua")) end },
		{ text = string.format("%s", lang.menu_public), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker announce.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_more_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker more bags.lua")) end },
		{ text = string.format("%s", lang.menu_less_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker less bags.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_secure_all), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure all.lua")) end }
	},
	["nail"] = {
		{ text = string.format("%s", lang.menu_autocook), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker.lua")) end },
		{ text = string.format("%s", lang.menu_semi_auto), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker semi auto.lua")) end },
		{ text = string.format("%s", lang.menu_auto_secure), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure.lua")) end },
		{ text = string.format("%s", lang.menu_auto_pill), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker bag meth.lua")) end },
		{ text = string.format("%s", lang.menu_public), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker announce.lua")) end },
		{ text = string.format("%s", lang.menu_less_spam), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker spam.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_more_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker more bags.lua")) end },
		{ text = string.format("%s", lang.menu_less_bags), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker less bags.lua")) end },
		{},
		{ text = string.format("%s", lang.menu_secure_all), callback_func = function() dofile(string.format(localization_TC.config.other.file_path.."autocooker secure all.lua")) end }
	},
}

local function mission_menu()
	local list = managers.job:current_level_id()
	
	local dialog_data = {    
		title = string.format("%s", lang.menu_title),
		text = string.format("%s", lang.menu_description),
		button_list = {}
	}
	
	for _, mission_func in pairs(mission_table[list]) do
		table.insert(dialog_data.button_list, mission_func)
	end

	table.insert(dialog_data.button_list, {})
	table.insert(dialog_data.button_list, { text = managers.localization:text("dialog_cancel"), cancel_button = true }) 
	managers.system_menu:show_buttons(dialog_data)
end

local function reconnect()
	local room_id = localization_TC["config"]["other"]["reconnect_id"]
	if room_id ~= "" then
		managers.network.matchmake:join_server(room_id)
		return
	end
	managers.mission._fading_debug_output:script().log(string.format("No server found.."), Color.red)
end

local main_menu_table = {
	{ text = string.format("%s", lang.m_menu_reconnect), callback_func = function()
		if in_mainmenu() then
			reconnect()
		else
			MenuCallbackHandler:_dialog_end_game_yes()
		end
	end }
}

local function reconnect_menu()
	local dialog_data = {    
		title = string.format("%s", lang.menu_title),
		text = string.format("%s", lang.menu_description),
		button_list = {}
	}
	
	for _, MM_func in pairs(main_menu_table) do
		table.insert(dialog_data.button_list, MM_func)
	end

	table.insert(dialog_data.button_list, {})
	table.insert(dialog_data.button_list, { text = managers.localization:text("dialog_cancel"), cancel_button = true }) 
	managers.system_menu:show_buttons(dialog_data)
end

if is_playing() then
	if not (id_level == 'pal' or id_level == 'nail' or id_level == 'cane' or id_level == 'mex_cooking' or id_level == 'alex_1' or id_level == 'rat' or id_level == 'crojob2' or id_level == 'mia_1') then
		managers.chat:_receive_message(1, lang.cooker, string.format("%s", lang.menu_heist_warning), tweak_data.system_chat_color)
		return
	end

	mission_menu()
else
	reconnect_menu()
end